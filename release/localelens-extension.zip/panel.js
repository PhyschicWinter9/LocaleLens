"use strict";
(() => {
  // ../../node_modules/.bun/preact@11.0.1/node_modules/preact/dist/preact.mjs
  var n;
  var t;
  var i;
  var r;
  var u;
  var f;
  var o;
  var e;
  var l;
  var c;
  var a;
  var s;
  var h = {};
  var p = [];
  var v = /^m(i|n|o|s|text|space)$/;
  var y = Array.isArray;
  var d = p.slice;
  var w = Object.assign;
  function _(n2) {
    n2 && n2.parentNode && n2.remove();
  }
  function b(i3, r3, u4, f3, o4) {
    var e3 = { type: i3, props: r3, key: u4, ref: f3, __k: null, __: null, __b: 0, __e: null, __c: null, constructor: void 0, __v: o4 || ++t, __i: -1, __u: 0 };
    return !o4 && n.vnode && n.vnode(e3), e3;
  }
  function M(n2) {
    return n2.children;
  }
  function $(n2, t3) {
    this.props = n2, this.context = t3, this.__g = 0;
  }
  function x(n2, t3) {
    if (null == t3) return n2.__ ? x(n2.__, n2.__i + 1) : null;
    for (var i3; t3 < n2.__k.length; t3++) if ((i3 = n2.__k[t3]) && i3.__e) return i3.__e;
    return "function" != typeof n2.type || n2.props.__P ? null : x(n2);
  }
  function S(n2) {
    if ((n2 = n2.__) && n2.__c && !n2.props.__P) return n2.__e = null, n2.__k.some(function(t3) {
      return t3 && (n2.__e = t3.__e);
    }), S(n2);
  }
  function C(t3) {
    (8 & t3.__g || !(t3.__g |= 8) || !r.push(t3) || f++) && u == n.debounceRendering || ((u = n.debounceRendering) || queueMicrotask)(j);
  }
  function j() {
    var t3, i3, u4, e3, l3, c3, a3, s3, h3;
    try {
      for (i3 = 1; r.length; ) r.length > i3 && r.sort(o), t3 = r.shift(), i3 = r.length, 8 & t3.__g && (e3 = void 0, l3 = void 0, c3 = (l3 = (u4 = t3).__v).__e, a3 = [], s3 = [], (h3 = u4.__P) && ((e3 = w({ constructor: void 0 }, l3)).__v = l3.__v + 1, n.vnode && n.vnode(e3), N(h3, e3, l3, u4.__n, h3.namespaceURI, 32 & l3.__u ? [c3] : null, a3, c3 || x(l3), 32 & l3.__u, s3), e3.__v = l3.__v, e3.__.__k[e3.__i] = e3, z(a3, e3, s3), l3.__ = l3.__e = null, e3.__e != c3 && S(e3)));
    } finally {
      r.length = f = 0;
    }
  }
  function L(n2, t3, i3, r3, u4, f3, o4, e3, l3, c3, a3) {
    var s3, v3, y3, d3, w2, _3, g2 = r3.__k || p, k2 = t3.length;
    for (l3 = H(i3, t3, g2, l3, k2), s3 = 0; s3 < k2; s3++) null != (y3 = i3.__k[s3]) && (v3 = ~y3.__i && g2[y3.__i] || h, y3.__i = s3, _3 = N(n2, y3, v3, u4, f3, o4, e3, l3, c3, a3), d3 = y3.__e, (v3.ref != y3.ref || 8 & v3.__u) && (v3.ref && D(v3.ref, null, y3, v3), y3.ref && a3.push(y3.ref, y3.__c || d3, y3)), w2 = w2 || d3, 4 & y3.__u ? (l3 = I(y3, l3, n2, !v3.__v), v3.__e && (v3.__e = null)) : "function" == typeof y3.type && void 0 !== _3 ? l3 = _3 : d3 && (l3 = d3.nextSibling), y3.__u &= -7);
    return i3.__e = w2, l3;
  }
  function H(n2, t3, i3, r3, u4) {
    var f3, o4, e3, l3, c3, a3, s3, h3, p3, v3, d3 = i3.length, w2 = d3, _3 = 0, g2 = false, k2 = n2.__k = Array(u4);
    for (f3 = 0; f3 < u4; f3++) null != (o4 = t3[f3]) && "boolean" != typeof o4 && "function" != typeof o4 ? ("object" != typeof o4 || o4.constructor == String ? o4 = k2[f3] = b(null, o4) : y(o4) ? o4 = k2[f3] = b(M, { children: o4 }) : void 0 === o4.constructor && o4.__b ? o4 = k2[f3] = b(o4.type, o4.props, o4.key, o4.ref, o4.__v) : k2[f3] = o4, l3 = f3 + _3, o4.__ = n2, o4.__b = n2.__b + 1, e3 = null, ~(c3 = o4.__i = O(o4, i3, l3, w2)) && (w2--, (e3 = i3[c3]) && (e3.__u |= 2)), e3 && e3.__v ? (o4.__u |= 2, c3 == l3 - 1 ? _3-- : c3 == l3 + 1 ? _3++ : c3 != l3 && (c3 > l3 ? _3-- : _3++, g2 = true)) : (~c3 || (u4 > d3 ? _3-- : u4 < d3 && _3++), "function" != typeof o4.type && (o4.__u |= 4))) : k2[f3] = null;
    if (g2) {
      for (a3 = [], s3 = [], f3 = 0; f3 < u4; f3++) if ((o4 = k2[f3]) && 2 & o4.__u) {
        for (h3 = 0, p3 = a3.length; h3 < p3; ) a3[v3 = h3 + p3 >> 1] < o4.__i ? h3 = v3 + 1 : p3 = v3;
        a3[h3] = o4.__i, s3[f3] = h3 + 1;
      }
      for (_3 = a3.length; f3--; ) s3[f3] && (s3[f3] == _3 ? _3-- : k2[f3].__u |= 4);
    }
    if (w2) for (f3 = 0; f3 < d3; f3++) !(e3 = i3[f3]) || 2 & e3.__u || (e3.__e == r3 && (r3 = x(e3)), E(e3, e3));
    return r3;
  }
  function I(n2, t3, i3, r3) {
    var u4, f3, o4;
    if ("function" == typeof n2.type) {
      if (n2.props.__P) return t3;
      if (u4 = n2.__k) for (f3 = 0; f3 < u4.length; f3++) u4[f3] && (u4[f3].__ = n2, t3 = I(u4[f3], t3, i3, false));
      return t3;
    }
    for (t3 && !t3.parentNode && (t3 = x(n2)) && !t3.parentNode && (t3 = null), o4 = t3; o4 && 8 == o4.nodeType; ) o4 = o4.nextSibling;
    for (n2.__e != o4 && (!r3 && i3.moveBefore && n2.__e.parentNode ? i3.moveBefore(n2.__e, t3) : i3.insertBefore(n2.__e, t3 || null)), t3 = n2.__e; (t3 = t3 && t3.nextSibling) && 8 == t3.nodeType; ) ;
    return t3;
  }
  function O(n2, t3, i3, r3) {
    var u4, f3, o4, e3 = n2.key, l3 = n2.type, c3 = t3[i3], a3 = c3 && !(2 & c3.__u);
    if (null === c3 && null == e3 || a3 && e3 == c3.key && l3 == c3.type) return i3;
    if (r3 > (a3 ? 1 : 0)) {
      for (u4 = i3 - 1, f3 = i3 + 1; u4 >= 0 || f3 < t3.length; ) if ((c3 = t3[o4 = u4 >= 0 ? u4-- : f3++]) && !(2 & c3.__u) && e3 == c3.key && l3 == c3.type) return o4;
    }
    return -1;
  }
  function P(n2, t3, i3) {
    null == i3 && (i3 = ""), "-" == t3[0] ? n2.setProperty(t3, i3) : n2[t3] = i3;
  }
  function T(n2, t3, i3, r3, u4) {
    var f3, o4;
    n: if ("style" == t3) if ("string" == typeof i3) n2.style.cssText = i3;
    else {
      if ("string" == typeof r3 && (n2.style.cssText = r3 = ""), r3) for (t3 in r3) i3 && t3 in i3 || P(n2.style, t3, "");
      if (i3) for (t3 in i3) r3 && i3[t3] == r3[t3] || P(n2.style, t3, i3[t3]);
    }
    else if ("o" == t3[0] && "n" == t3[1]) (n2.__e || (n2.__e = {}))[t3] = i3, i3 && r3 || (o4 = a[t3] || (a[t3] = q(t3)), (n2.__a || (n2.__a = {}))[t3] = c, f3 = t3 != (t3 = t3.replace(l, "$1")), (t3 = t3.slice(2))[0] < "a" && (t3 = t3.toLowerCase()), i3 ? n2.addEventListener(t3, o4, f3) : n2.removeEventListener(t3, o4, f3));
    else {
      if ("http://www.w3.org/2000/svg" == u4) t3 = t3.replace(/xlink(H|:h)/, "h").replace(/sName$/, "s");
      else if ("width" != t3 && "height" != t3 && "href" != t3 && "list" != t3 && "form" != t3 && "tabIndex" != t3 && "download" != t3 && "rowSpan" != t3 && "colSpan" != t3 && "role" != t3 && "popover" != t3 && t3 in n2) try {
        n2[t3] = null == i3 ? "" : i3;
        break n;
      } catch (n3) {
      }
      "function" == typeof i3 || (null == i3 || false === i3 && "-" != t3[4] ? n2.removeAttribute(t3) : n2.setAttribute(t3, "popover" == t3 && 1 == i3 ? "" : i3));
    }
  }
  function q(t3) {
    return function(i3) {
      if (this.__e) {
        var r3 = this.__e[t3];
        if (null == i3[e]) i3[e] = c++;
        else if (i3[e] < this.__a[t3]) return;
        return r3(n.event ? n.event(i3) : i3);
      }
    };
  }
  function N(t3, i3, r3, u4, f3, o4, e3, l3, c3, a3) {
    var s3, h3, v3, d3, g2, k2, b3, m2, S2, C3, j3, H2, I2, A2, O2, P2, T3, q2, N2, z3, D3 = i3.type;
    if (void 0 !== i3.constructor) return null;
    if (128 & r3.__u && (c3 = 32 & r3.__u, s3 = r3.__c.__z)) {
      if (i3.__u |= c3, h3 = o4 = [], 8 == s3.nodeType) for (v3 = 1, d3 = s3.nextSibling; d3; d3 = d3.nextSibling) {
        if (8 == d3.nodeType) {
          if (d3.data.startsWith("$s")) v3++;
          else if (d3.data.startsWith("/$s") && !--v3) break;
        }
        o4.push(d3);
      }
      else o4.push(s3);
      l3 = o4[0];
    }
    (s3 = n.__b) && s3(i3);
    n: if ("function" == typeof D3) {
      g2 = e3.length;
      try {
        if (C3 = i3.props, j3 = (s3 = D3.prototype) && s3.render, H2 = (s3 = D3.contextType) && u4[s3.__c], I2 = s3 ? H2 ? H2.props.value : s3.__ : u4, r3.__c ? 2 & (k2 = i3.__c = r3.__c).__g && (k2.__g |= 1) : (j3 ? i3.__c = k2 = new D3(C3, I2) : (i3.__c = k2 = new $(C3, I2), k2.constructor = D3, k2.render = F), H2 && H2.sub(k2), k2.state || (k2.state = {}), k2.__n = u4, k2.__g |= 8, k2.__h = [], k2.__k = []), j3 && (k2.__s || (k2.__s = k2.state), D3.getDerivedStateFromProps && (k2.__s == k2.state && (k2.__s = w({}, k2.__s)), w(k2.__s, D3.getDerivedStateFromProps(C3, k2.__s)))), b3 = k2.props, m2 = k2.state, k2.__v = i3, r3.__c) {
          if (j3 && !D3.getDerivedStateFromProps && C3 !== b3 && k2.componentWillReceiveProps && k2.componentWillReceiveProps(C3, I2), i3.__v == r3.__v && !(8 & k2.__g) || !(4 & k2.__g) && k2.shouldComponentUpdate && false === k2.shouldComponentUpdate(C3, k2.__s, I2)) {
            i3.__v != r3.__v && (k2.props = C3, k2.state = k2.__s, k2.__g &= -9), i3.__e = r3.__e, i3.__k = r3.__k, i3.__k.some(function(n2) {
              n2 && (n2.__ = i3);
            }), p.push.apply(k2.__h, k2.__k), k2.__k = [], k2.__h.length && e3.push(k2), l3 = x(r3);
            break n;
          }
          k2.componentWillUpdate && k2.componentWillUpdate(C3, k2.__s, I2), j3 && k2.componentDidUpdate && k2.__h.push(function() {
            k2.componentDidUpdate(b3, m2, S2);
          });
        } else j3 && !D3.getDerivedStateFromProps && k2.componentWillMount && k2.componentWillMount(), j3 && k2.componentDidMount && k2.__h.push(k2.componentDidMount);
        if (k2.context = I2, k2.props = C3, k2.__P = t3, k2.__g &= -5, A2 = n.__r, O2 = 0, j3) k2.state = k2.__s, k2.__g &= -9, A2 && A2(i3), s3 = k2.render(k2.props, k2.state, k2.context), p.push.apply(k2.__h, k2.__k), k2.__k = [];
        else do {
          k2.__g &= -9, A2 && A2(i3), s3 = k2.render(k2.props, k2.state, k2.context), k2.state = k2.__s;
        } while (8 & k2.__g && ++O2 < 25);
        k2.state = k2.__s, k2.getChildContext && (u4 = w({}, u4, k2.getChildContext())), j3 && r3.__c && k2.getSnapshotBeforeUpdate && (S2 = k2.getSnapshotBeforeUpdate(b3, m2)), P2 = s3 && s3.type === M && null == s3.key ? s3.props.children : s3, C3.__P && (s3 = l3, f3 = (t3 = C3.__P).namespaceURI, c3 = o4 = null, r3.props && r3.props.__P != t3 && (r3.__k.some(function(n2) {
          n2 && E(n2, n2);
        }), r3.__k = null), l3 = r3.__k ? x(r3, 0) : null), l3 = L(t3, y(P2) ? P2 : [P2], i3, r3, u4, f3, o4, e3, l3, c3, a3), C3.__P && (i3.__e = null, l3 = s3), i3.__u &= -161, 128 & r3.__u && (k2.__z = null), h3 && h3.some(_), k2.__h.length && e3.push(k2), 1 & k2.__g && (k2.__g &= -4);
      } catch (t4) {
        if (e3.length = g2, i3.__v = null, c3 || o4) if (t4.then) {
          if (T3 = 0, i3.__u |= c3 ? 160 : 128, o4) {
            for (~(N2 = o4.indexOf(l3 || void 0)) || (N2 = o4.length); (z3 = o4[N2 - 1]) && 8 == z3.nodeType; ) N2--;
            for (; N2 < o4.length; N2++) if (z3 = o4[N2]) {
              if (o4[N2] = null, 8 == z3.nodeType) {
                if (z3.data.startsWith("$s")) T3++ || (q2 = z3);
                else if (T3 && z3.data.startsWith("/$s") && !--T3) {
                  l3 = z3;
                  break;
                }
              } else if (!T3) break;
            }
          }
          if (!q2) {
            for (; l3 && 8 == l3.nodeType && l3.nextSibling; ) l3 = l3.nextSibling;
            q2 = l3;
          }
          i3.__c.__z || (i3.__c.__z = q2), i3.__e = l3;
        } else o4 && o4.some(_);
        else i3.__e = r3.__e;
        i3.__k || (i3.__k = r3.__k || []), t4.then || V(i3), n.__e(t4, i3, r3);
      }
    } else l3 = i3.__e = B(r3.__e, i3, r3, u4, f3, o4, e3, c3, a3, t3);
    return (s3 = n.diffed) && s3(i3), 128 & i3.__u ? void 0 : l3;
  }
  function V(n2) {
    n2 && (n2.__c && (n2.__c.__g |= 4), n2.__k && n2.__k.some(V));
  }
  function z(t3, i3, r3) {
    for (var u4 = 0; u4 < r3.length; ) D(r3[u4++], r3[u4++], r3[u4++]);
    n.__c && n.__c(i3, t3), t3.some(function(i4) {
      try {
        t3 = i4.__h, i4.__h = [], t3.some(function(n2) {
          n2.call(i4);
        });
      } catch (t4) {
        n.__e(t4, i4.__v);
      }
    });
  }
  function B(t3, i3, r3, u4, f3, o4, e3, l3, c3, a3) {
    var s3, p3, w2, g2, k2, b3, m2, M2, $2, S2 = r3.props || h, C3 = i3.props, j3 = i3.type;
    if ("svg" == j3 ? f3 = "http://www.w3.org/2000/svg" : "math" == j3 ? f3 = "http://www.w3.org/1998/Math/MathML" : f3 || (f3 = "http://www.w3.org/1999/xhtml"), o4) {
      for (s3 = 0; s3 < o4.length; s3++) if ((k2 = o4[s3]) && (j3 ? k2.localName == j3 : 3 == k2.nodeType)) {
        t3 = k2, o4[s3] = null;
        break;
      }
    }
    if (!t3) {
      if (M2 = a3.ownerDocument || document, !j3) return M2.createTextNode(C3);
      t3 = M2.createElementNS(f3, j3, C3.is && C3), l3 && (n.__m && n.__m(i3, o4), l3 = false), o4 = null;
    }
    if (j3) {
      if (a3 = "template" == j3 ? t3.content : t3, o4 = "textarea" == j3 && null != C3.defaultValue ? null : o4 && d.call(a3.childNodes), !l3 && o4) for (S2 = {}, s3 = 0; s3 < t3.attributes.length; s3++) S2[(k2 = t3.attributes[s3]).name] = k2.value;
      for (s3 in S2) k2 = S2[s3], "dangerouslySetInnerHTML" == s3 ? w2 = k2 : "children" == s3 || s3 in C3 || "value" == s3 && "defaultValue" in C3 || "checked" == s3 && "defaultChecked" in C3 || T(t3, s3, null, k2, f3);
      for (s3 in $2 = 1 & r3.__u, C3) k2 = C3[s3], "children" == s3 ? g2 = k2 : "dangerouslySetInnerHTML" == s3 ? p3 = k2 : "value" == s3 ? b3 = k2 : "checked" == s3 ? m2 = k2 : l3 && "function" != typeof k2 || !(S2[s3] !== k2 || $2 && null != k2) || T(t3, s3, k2, S2[s3], f3);
      p3 ? (l3 || w2 && (p3.__html == w2.__html || p3.__html == t3.innerHTML) || (t3.innerHTML = p3.__html), i3.__k = []) : (w2 && (t3.textContent = ""), ("foreignObject" == j3 || "http://www.w3.org/1998/Math/MathML" == f3 && v.test(j3)) && (f3 = "http://www.w3.org/1999/xhtml"), L(a3, y(g2) ? g2 : [g2], i3, r3, u4, f3, o4, e3, o4 ? o4[0] : r3.__k && x(r3, 0), l3, c3), o4 && o4.some(_)), l3 && "textarea" != j3 || (s3 = "value", "progress" == j3 && null == b3 ? t3.removeAttribute(s3) : null == b3 || b3 === t3[s3] && ("progress" != j3 || b3) || T(t3, s3, b3, S2[s3], f3), s3 = "checked", null != m2 && m2 != t3[s3] && T(t3, s3, m2, S2[s3], f3));
    } else S2 === C3 || l3 && t3.data == C3 || (t3.data = C3);
    return t3;
  }
  function D(t3, i3, r3, u4) {
    try {
      "function" == typeof t3 ? i3 ? i3.__x = t3(i3) || 1 : u4 && (u4 = u4.__c || u4.__e) && (i3 = u4.__x) && (u4.__x = null, "function" == typeof i3 ? i3() : t3(null)) : t3.current = i3;
    } catch (t4) {
      n.__e(t4, r3);
    }
  }
  function E(t3, i3, r3) {
    var u4, f3;
    if (n.unmount && n.unmount(t3), !(u4 = t3.ref) || u4.current && u4.current != t3.__e || D(u4, null, i3, t3), u4 = t3.__c) {
      if (u4.componentWillUnmount) try {
        u4.componentWillUnmount();
      } catch (t4) {
        n.__e(t4, i3);
      }
      u4.__P = u4.__n = null;
    }
    if (u4 = t3.__k) for (f3 = 0; f3 < u4.length; f3++) u4[f3] && E(u4[f3], i3, "function" != typeof t3.type || r3 && !t3.props.__P);
    (u4 = t3.__e) && (r3 || _(u4), u4.__e && (u4.__e = null)), t3.__e = t3.__c = t3.__ = null;
  }
  function F(n2, t3, i3) {
    return this.constructor(n2, i3);
  }
  function G(t3, i3) {
    var r3, u4, f3, o4;
    n.__ && n.__(t3, i3), 9 == i3.nodeType && (i3 = i3.documentElement), u4 = (r3 = t3 && 32 & t3.__u) ? null : i3.__k, i3.__k = b(M, { children: [t3] }), f3 = [], o4 = [], N(i3, i3.__k, u4 || h, h, i3.namespaceURI, u4 ? null : i3.firstChild ? d.call(i3.childNodes) : null, f3, u4 ? u4.__e : i3.firstChild, r3, o4), z(f3, i3.__k, o4), i3.__k.props.children = null;
  }
  n = { __e: function(n2, t3, i3, r3) {
    for (var u4, o4, e3; t3 = t3.__; ) if ((u4 = t3.__c) && !(1 & u4.__g)) {
      u4.__g |= 4;
      try {
        if ((o4 = u4.constructor) && o4.getDerivedStateFromError && (u4.setState(o4.getDerivedStateFromError(n2)), e3 = 8 & u4.__g), u4.componentDidCatch && (u4.componentDidCatch(n2, r3 || {}), e3 = 8 & u4.__g), e3) return void (u4.__g |= 2);
      } catch (t4) {
        n2 = t4, e3 = 0;
      }
    }
    throw f = 0, n2;
  } }, t = 0, i = function(n2) {
    return null != n2 && void 0 === n2.constructor;
  }, $.prototype.setState = function(n2, t3) {
    var i3 = this.__s;
    i3 && i3 != this.state || (i3 = this.__s = w({}, this.state)), "function" == typeof n2 && (n2 = n2(w({}, i3), this.props)), n2 && (w(i3, n2), this.__v && (t3 && this.__k.push(t3), C(this)));
  }, $.prototype.forceUpdate = function(n2) {
    this.__v && (this.__g |= 4, n2 && this.__h.push(n2), C(this));
  }, $.prototype.render = M, r = [], f = 0, o = function(n2, t3) {
    return n2.__v.__b - t3.__v.__b;
  }, e = /* @__PURE__ */ Symbol(), l = /(PointerCapture)$|Capture$/i, c = 0, a = {}, s = 0;

  // ../../node_modules/.bun/preact@11.0.1/node_modules/preact/hooks/dist/hooks.mjs
  var t2;
  var r2;
  var u2;
  var i2;
  var o2 = Object.is;
  var f2 = 0;
  var c2 = [];
  var e2 = [];
  var a2 = n;
  var v2 = a2.__b;
  var l2 = a2.__r;
  var m = a2.diffed;
  var s2 = a2.__c;
  var h2 = a2.unmount;
  var p2 = a2.__;
  function y2(n2, t3) {
    a2.__h && a2.__h(r2, n2, f2 || t3), f2 = 0;
    var u4 = r2.__H || (r2.__H = { __: [], __h: [] });
    return n2 >= u4.__.length && u4.__.push({}), u4.__[n2];
  }
  function d2(n2) {
    return f2 = 1, _2(G2, n2);
  }
  function _2(n2, u4, i3) {
    var f3 = y2(t2++, 2);
    if (f3.t = n2, !f3.__c && (f3.__ = [i3 ? i3(u4) : G2(void 0, u4), function(n3) {
      var t3 = f3.__N ? f3.__N[0] : f3.__[0], r3 = f3.t(t3, n3);
      o2(t3, r3) || (f3.__N = [r3, f3.__[1]], f3.__c.setState({}));
    }], f3.__c = r2, !r2.__f)) {
      r2.__f = true;
      var c3 = r2.shouldComponentUpdate;
      r2.shouldComponentUpdate = function(n3, t3, r3) {
        var u5 = this.__H;
        if (!u5) return true;
        var i4 = false, f4 = this.props != n3;
        if (u5.__.some(function(n4) {
          n4.__N && (i4 = true, o2(n4.__[0], n4.__N[0]) || (f4 = true));
        }), c3) {
          var e3 = c3.call(this, n3, t3, r3);
          return i4 ? e3 || f4 : e3;
        }
        return !i4 || f4;
      };
    }
    return f3.__;
  }
  function A(n2, u4) {
    var i3 = y2(t2++, 3);
    !a2.__s && E2(i3.__H, u4) && (i3.__P = true, i3.__ = n2, i3.u = u4, r2.__H.__h.push(i3));
  }
  function T2(n2) {
    return f2 = 5, b2(function() {
      return { current: n2 };
    }, []);
  }
  function b2(n2, r3) {
    var u4 = y2(t2++, 7);
    return E2(u4.__H, r3) && (u4.__ = n2(), u4.__H = r3), u4.__;
  }
  function j2(n2, t3) {
    return f2 = 8, b2(function() {
      return n2;
    }, t3);
  }
  function g() {
    var n2;
    do {
      for (; n2 = e2.shift(); ) try {
        C2(n2);
      } catch (t4) {
        a2.__e(t4, { __: (n2 = n2.__P) && n2.__v });
      }
      for (; n2 = c2.shift(); ) {
        var t3 = n2.__H;
        if (n2.__P && t3) try {
          t3.__h.some(C2), t3.__h.some(D2), t3.__h = [];
        } catch (r3) {
          t3.__h = [], a2.__e(r3, n2.__v);
        }
      }
    } while (e2.length);
  }
  a2.__b = function(n2) {
    r2 = null, v2 && v2(n2);
  }, a2.__ = function(n2, t3) {
    n2 && t3.__k && t3.__k.__m && (n2.__m = t3.__k.__m), p2 && p2(n2, t3);
  }, a2.__r = function(n2) {
    l2 && l2(n2), t2 = 0;
    var i3 = (r2 = n2.__c).__H;
    i3 && (u2 == r2 ? r2.__h = [] : (i3.__h.some(C2), i3.__h.some(D2), t2 = 0), i3.__h = [], i3.__.some(function(n3) {
      n3.__N && (n3.__ = n3.__N), n3.u = n3.__N = void 0;
    })), u2 = r2;
  }, a2.diffed = function(n2) {
    m && m(n2);
    var t3 = n2.__c;
    t3 && t3.__H && (t3.__H.__h.length && B2(c2.push(t3)), t3.__H.__.some(function(n3) {
      n3.u && (n3.__H = n3.u);
    })), u2 = r2 = null;
  }, a2.__c = function(n2, t3) {
    t3.some(function(n3) {
      try {
        n3.__h.some(C2), n3.__h = n3.__h.filter(function(n4) {
          return !n4.__ || D2(n4);
        });
      } catch (r3) {
        t3.some(function(n4) {
          n4.__h && (n4.__h = []);
        }), t3 = [], a2.__e(r3, n3.__v);
      }
    }), s2 && s2(n2, t3);
  }, a2.unmount = function(n2) {
    h2 && h2(n2);
    var t3, r3, u4 = n2.__c;
    u4 && u4.__H && (u4.__H.__.some(function(u5) {
      try {
        if (u5.__P && u5.__c) {
          if (void 0 === r3) {
            for (r3 = n2.__; r3 && (!r3.__c || !r3.__c.__P); ) r3 = r3.__;
            r3 = r3 && r3.__c;
          }
          u5.__P = r3, B2(e2.push(u5));
        } else C2(u5);
      } catch (n3) {
        t3 = n3;
      }
    }), u4.__H = void 0, t3 && a2.__e(t3, u4.__v));
  };
  var k = "function" == typeof requestAnimationFrame;
  function z2(n2) {
    var t3, r3 = function() {
      clearTimeout(u4), k && cancelAnimationFrame(t3), setTimeout(n2);
    }, u4 = setTimeout(r3, 35);
    k && (t3 = requestAnimationFrame(r3));
  }
  function B2(n2) {
    1 != n2 && i2 == a2.requestAnimationFrame || ((i2 = a2.requestAnimationFrame) || z2)(g);
  }
  function C2(n2) {
    var t3 = r2, u4 = n2.__c;
    "function" == typeof u4 && (n2.__c = void 0, u4()), r2 = t3;
  }
  function D2(n2) {
    var t3 = r2;
    n2.__c = n2.__(), r2 = t3;
  }
  function E2(n2, t3) {
    return !n2 || n2.length != t3.length || t3.some(function(t4, r3) {
      return !o2(t4, n2[r3]);
    });
  }
  function G2(n2, t3) {
    return "function" == typeof t3 ? t3(n2) : t3;
  }

  // src/common.ts
  var RpcError = class extends Error {
    constructor(code, message, component = "unknown") {
      super(message);
      this.code = code;
      this.component = component;
    }
    code;
    component;
  };
  var uid = () => crypto.randomUUID().slice(0, 12);
  async function rpc(type, payload, opts = {}) {
    const req = { v: 1, kind: "req", id: uid(), type, tabId: opts.tabId, payload };
    const timeoutMs = opts.timeoutMs ?? 1e4;
    let timer;
    const timeout = new Promise((_3, rej) => {
      timer = setTimeout(() => rej(new RpcError("TIMEOUT", `No response to ${type} within ${timeoutMs}ms`, "messaging")), timeoutMs);
    });
    try {
      const res = await Promise.race([chrome.runtime.sendMessage(req), timeout]);
      if (!res) throw new RpcError("NO_RECEIVER", `Nobody answered ${type} (background worker not reachable)`, "messaging");
      if (!res.ok) throw new RpcError(res.error?.code ?? "ERROR", res.error?.message ?? "Request failed", res.error?.component ?? "unknown");
      return res.payload;
    } catch (e3) {
      if (e3 instanceof RpcError) throw e3;
      throw new RpcError("NO_RECEIVER", e3.message || "Messaging failed", "messaging");
    } finally {
      clearTimeout(timer);
    }
  }
  function logEvt(component, level, event, extra = {}) {
    const entry = { ts: (/* @__PURE__ */ new Date()).toISOString(), level, component, event, ...extra };
    const evt = { v: 1, kind: "evt", type: "log", payload: entry };
    try {
      void chrome.runtime.sendMessage(evt).catch(() => {
      });
    } catch {
    }
  }
  function parseRef(s3) {
    const m2 = /^([a-f0-9]{8}):(\d+):([a-f0-9]{8})$/.exec(s3 ?? "");
    return m2 ? { fileId: m2[1], n: Number(m2[2]), fp: m2[3] } : null;
  }

  // src/panel/api.ts
  var params = new URLSearchParams(location.search);
  var tabId = typeof chrome !== "undefined" && chrome.devtools?.inspectedWindow?.tabId || Number(params.get("inspectedTabId")) || -1;
  var initialTab = params.get("tab") ?? "inspector";
  async function api(method, path, body, timeoutMs) {
    return rpc("bg.agent.call", { method, path, body, timeoutMs });
  }
  async function page(type, payload, timeoutMs = 5e3) {
    if (tabId < 0) throw new RpcError("NO_TAB", "No inspected tab. Open this panel from DevTools of your app tab.", "panel");
    return rpc("bg.toTab", { tabId, type, payload, timeoutMs }, { timeoutMs: timeoutMs + 3e3 });
  }
  var plog = (level, event, extra = {}) => logEvt("panel", level, event, extra);
  var REDACT = /(Bearer\s+)[A-Za-z0-9._~+/=-]+|\bll_[A-Za-z0-9_-]{20,}\b/g;
  var sanitizeText = (s3) => s3.replace(REDACT, (_m, p3) => p3 ? p3 + "[redacted]" : "[redacted]");
  function download(name, text) {
    const a3 = document.createElement("a");
    a3.href = URL.createObjectURL(new Blob([text], { type: "application/json" }));
    a3.download = name;
    a3.click();
    setTimeout(() => URL.revokeObjectURL(a3.href), 1e3);
  }

  // ../../node_modules/.bun/preact@11.0.1/node_modules/preact/jsx-runtime/dist/jsxRuntime.mjs
  var o3 = 0;
  function u3(t3, e3, n2, f3, u4, i3) {
    e3 || (e3 = {});
    var a3, c3, l3 = e3;
    if ("ref" in l3 && "function" != typeof t3) for (c3 in l3 = {}, e3) "ref" == c3 ? a3 = e3[c3] : l3[c3] = e3[c3];
    var p3 = { type: t3, props: l3, key: n2, ref: a3, __k: null, __: null, __b: 0, __e: null, __c: null, constructor: void 0, __v: --o3, __i: -1, __u: 0 };
    return (u4 || i3) && (p3.__source = u4, p3.__self = i3), n.vnode && n.vnode(p3), p3;
  }

  // src/panel/views.tsx
  var Diff = ({ text }) => /* @__PURE__ */ u3("div", { class: "diff", role: "region", "aria-label": "diff", children: text.split("\n").map((l3, i3) => /* @__PURE__ */ u3("div", { class: l3.startsWith("+") ? "a" : l3.startsWith("-") ? "d" : l3.startsWith("@@") ? "h" : "", children: l3 || " " }, i3)) });
  var Empty = ({ children }) => /* @__PURE__ */ u3("div", { class: "empty", children });
  var errText = (e3) => `${e3?.message ?? e3}${e3?.code ? ` (${e3.code})` : ""}`;
  function b64ToBlob(b64, mime) {
    const bin = atob(b64);
    const u4 = new Uint8Array(bin.length);
    for (let i3 = 0; i3 < bin.length; i3++) u4[i3] = bin.charCodeAt(i3);
    return new Blob([u4], { type: mime });
  }
  async function fileToB64(file) {
    const buf = new Uint8Array(await file.arrayBuffer());
    let bin = "";
    for (let i3 = 0; i3 < buf.length; i3 += 32768) bin += String.fromCharCode(...buf.subarray(i3, i3 + 32768));
    return btoa(bin);
  }
  function Exchange({ onDone }) {
    const [pv, setPv] = d2(null);
    const [res, setRes] = d2({});
    const [msg, setMsg] = d2(null);
    const [busy, setBusy] = d2(false);
    const doExport = async () => {
      setBusy(true);
      setMsg(null);
      try {
        const r3 = await api("POST", "/translations/export", { format: "zip" });
        const a3 = document.createElement("a");
        a3.href = URL.createObjectURL(b64ToBlob(r3.dataBase64, r3.mime));
        a3.download = r3.fileName;
        a3.click();
        setMsg({ kind: "ok", text: `Exported ${r3.count} keys to ${r3.fileName}. Send it to translators; they only need Excel.` });
      } catch (e3) {
        setMsg({ kind: "err", text: errText(e3) });
      } finally {
        setBusy(false);
      }
    };
    const doPreview = async (file) => {
      setBusy(true);
      setMsg(null);
      setPv(null);
      setRes({});
      try {
        setPv(await api("POST", "/translations/import/preview", { dataBase64: await fileToB64(file) }, 6e4));
        plog("INFO", "import.preview.completed");
      } catch (e3) {
        setMsg({ kind: "err", text: errText(e3) });
      } finally {
        setBusy(false);
      }
    };
    const doCommit = async () => {
      setBusy(true);
      setMsg(null);
      try {
        const r3 = await api("POST", "/translations/import/commit", { importId: pv.importId, resolutions: res });
        setMsg({ kind: "ok", text: `Applied ${r3.applied} change(s) (transaction ${r3.transactionId ?? "none"}). Undo from Changes / Diff.` });
        setPv(null);
        onDone();
      } catch (e3) {
        setMsg({ kind: "err", text: errText(e3) });
      } finally {
        setBusy(false);
      }
    };
    const unresolved = pv ? pv.report.conflicts.filter((c3) => !res[c3.conflictId]) : [];
    return /* @__PURE__ */ u3("div", { class: "card", children: [
      /* @__PURE__ */ u3("h3", { children: "Translator exchange" }),
      /* @__PURE__ */ u3("div", { class: "body", children: [
        /* @__PURE__ */ u3("div", { class: "row", children: [
          /* @__PURE__ */ u3("button", { onClick: doExport, disabled: busy, children: "Export package (.zip)" }),
          /* @__PURE__ */ u3("label", { class: "row", style: "display:inline-flex", children: [
            /* @__PURE__ */ u3("span", { class: "muted", children: "Import returned file" }),
            /* @__PURE__ */ u3("input", { type: "file", accept: ".xlsx,.zip", style: "width:auto", onChange: (e3) => {
              const f3 = e3.target.files?.[0];
              if (f3) void doPreview(f3);
            } })
          ] })
        ] }),
        msg && /* @__PURE__ */ u3("div", { class: "alert " + (msg.kind === "ok" ? "ok" : "err"), role: "status", children: msg.text }),
        pv && /* @__PURE__ */ u3(M, { children: [
          /* @__PURE__ */ u3("div", { class: "muted", children: [
            pv.report.changes.length,
            " change(s) \xB7 ",
            pv.report.conflicts.length,
            " conflict(s) \xB7 ",
            pv.report.invalid.length,
            " invalid \xB7 ",
            pv.report.unchanged + pv.report.alreadyApplied,
            " unchanged",
            pv.hasBase ? "" : " \xB7 no base snapshot in file"
          ] }),
          pv.warnings.map((w2, i3) => /* @__PURE__ */ u3("div", { class: "alert warn", children: w2 }, i3)),
          pv.report.invalid.map((i3, k2) => /* @__PURE__ */ u3("div", { class: "alert err", children: [
            /* @__PURE__ */ u3("b", { class: "mono", children: i3.key }),
            " [",
            i3.locale,
            "] ",
            i3.message
          ] }, k2)),
          pv.report.conflicts.map((c3) => /* @__PURE__ */ u3("div", { class: "card", children: [
            /* @__PURE__ */ u3("div", { class: "filebar", children: [
              /* @__PURE__ */ u3("span", { class: "badge warn", children: c3.reason }),
              c3.key,
              " [",
              c3.locale,
              "]"
            ] }),
            /* @__PURE__ */ u3("div", { class: "body", children: [
              /* @__PURE__ */ u3("table", { children: /* @__PURE__ */ u3("tbody", { children: [
                /* @__PURE__ */ u3("tr", { children: [
                  /* @__PURE__ */ u3("td", { class: "muted", children: "at export" }),
                  /* @__PURE__ */ u3("td", { children: c3.base ?? "\u2014" })
                ] }),
                /* @__PURE__ */ u3("tr", { children: [
                  /* @__PURE__ */ u3("td", { class: "muted", children: "project now" }),
                  /* @__PURE__ */ u3("td", { children: c3.current ?? "(deleted)" })
                ] }),
                /* @__PURE__ */ u3("tr", { children: [
                  /* @__PURE__ */ u3("td", { class: "muted", children: "translator" }),
                  /* @__PURE__ */ u3("td", { children: c3.incoming })
                ] })
              ] }) }),
              /* @__PURE__ */ u3("div", { class: "row", role: "radiogroup", "aria-label": "Resolve " + c3.key, children: ["current", "incoming"].map((v3) => /* @__PURE__ */ u3("label", { class: "row", style: "display:inline-flex", children: [
                /* @__PURE__ */ u3("input", { type: "radio", style: "width:auto", name: c3.conflictId, checked: res[c3.conflictId] === v3, onChange: () => setRes({ ...res, [c3.conflictId]: v3 }) }),
                v3 === "current" ? "Keep project" : "Use translator"
              ] }, v3)) })
            ] })
          ] }, c3.conflictId)),
          pv.changes.map((c3) => /* @__PURE__ */ u3("div", { children: [
            /* @__PURE__ */ u3("div", { class: "filebar", children: [
              c3.file,
              c3.created && /* @__PURE__ */ u3("span", { class: "badge ok", children: "new" })
            ] }),
            /* @__PURE__ */ u3(Diff, { text: c3.diff })
          ] }, c3.file)),
          /* @__PURE__ */ u3("div", { class: "row", children: [
            /* @__PURE__ */ u3("button", { class: "primary", onClick: doCommit, disabled: busy || unresolved.length > 0 || !pv.report.changes.length && !Object.keys(res).length, children: "Apply import" }),
            /* @__PURE__ */ u3("button", { onClick: () => setPv(null), children: "Cancel" }),
            unresolved.length > 0 && /* @__PURE__ */ u3("span", { class: "muted", children: [
              "Resolve ",
              unresolved.length,
              " conflict(s) first. Nothing is overwritten silently."
            ] })
          ] })
        ] })
      ] })
    ] });
  }
  function Translations({ connected, onEdit }) {
    const [data, setData] = d2(null);
    const [q2, setQ] = d2("");
    const [err, setErr] = d2("");
    const load = () => api("GET", "/translations/list").then((d3) => {
      setData(d3);
      setErr("");
    }).catch((e3) => setErr(errText(e3)));
    A(() => {
      if (connected) void load();
    }, [connected]);
    if (!connected) return /* @__PURE__ */ u3(Empty, { children: "Connect to the agent first." });
    const rows = (data?.entries ?? []).filter((e3) => !q2 || (e3.key + e3.namespace + Object.values(e3.values).join(" ")).toLowerCase().includes(q2.toLowerCase()));
    return /* @__PURE__ */ u3("div", { class: "stack", children: [
      /* @__PURE__ */ u3(Exchange, { onDone: load }),
      /* @__PURE__ */ u3("div", { class: "row", children: [
        /* @__PURE__ */ u3("input", { "aria-label": "Filter translations", placeholder: "Filter by key or text", value: q2, onInput: (e3) => setQ(e3.target.value), style: "max-width:320px" }),
        /* @__PURE__ */ u3("button", { onClick: load, children: "Refresh" }),
        /* @__PURE__ */ u3("span", { class: "muted", children: [
          rows.length,
          " entries"
        ] })
      ] }),
      err && /* @__PURE__ */ u3("div", { class: "alert err", children: err }),
      /* @__PURE__ */ u3("table", { children: [
        /* @__PURE__ */ u3("thead", { children: /* @__PURE__ */ u3("tr", { children: [
          /* @__PURE__ */ u3("th", { children: "Key" }),
          /* @__PURE__ */ u3("th", { children: "NS" }),
          /* @__PURE__ */ u3("th", { children: "WS" }),
          (data?.locales ?? []).map((l3) => /* @__PURE__ */ u3("th", { children: l3 }, l3))
        ] }) }),
        /* @__PURE__ */ u3("tbody", { children: rows.slice(0, 500).map((e3) => /* @__PURE__ */ u3("tr", { class: "click", tabIndex: 0, onClick: () => onEdit(e3), onKeyDown: (k2) => k2.key === "Enter" && onEdit(e3), children: [
          /* @__PURE__ */ u3("td", { class: "mono", children: e3.key }),
          /* @__PURE__ */ u3("td", { children: e3.namespace }),
          /* @__PURE__ */ u3("td", { children: e3.workspaceId }),
          (data?.locales ?? []).map((l3) => /* @__PURE__ */ u3("td", { children: e3.values[l3] ?? /* @__PURE__ */ u3("span", { class: "badge warn", children: "missing" }) }, l3))
        ] }, e3.workspaceId + e3.namespace + e3.key)) })
      ] })
    ] });
  }
  function MissingKeys({ connected, onEdit }) {
    const [t3, setT] = d2(null);
    const [scan, setScan] = d2(null);
    const [err, setErr] = d2("");
    const load = () => Promise.all([api("GET", "/translations/list"), api("GET", "/scan", void 0, 6e4)]).then(([a3, b3]) => {
      setT(a3);
      setScan(b3);
      setErr("");
    }).catch((e3) => setErr(errText(e3)));
    A(() => {
      if (connected) void load();
    }, [connected]);
    if (!connected) return /* @__PURE__ */ u3(Empty, { children: "Connect to the agent first." });
    const partial = (t3?.entries ?? []).filter((e3) => e3.missing.length);
    return /* @__PURE__ */ u3("div", { class: "stack", children: [
      /* @__PURE__ */ u3("div", { class: "row", children: [
        /* @__PURE__ */ u3("button", { onClick: load, children: "Rescan" }),
        err && /* @__PURE__ */ u3("span", { class: "badge err", children: err })
      ] }),
      /* @__PURE__ */ u3("div", { class: "card", children: [
        /* @__PURE__ */ u3("h3", { children: [
          "Keys used in code but defined nowhere (",
          scan?.missingKeys?.length ?? 0,
          ")"
        ] }),
        /* @__PURE__ */ u3("table", { children: /* @__PURE__ */ u3("tbody", { children: (scan?.missingKeys ?? []).map((m2, i3) => /* @__PURE__ */ u3("tr", { class: "click", tabIndex: 0, onClick: () => onEdit({ namespace: m2.namespace, key: m2.key, values: {}, workspaceId: "" }), children: [
          /* @__PURE__ */ u3("td", { class: "mono", children: [
            m2.namespace,
            ":",
            m2.key
          ] }),
          /* @__PURE__ */ u3("td", { class: "muted", children: [
            m2.file,
            ":",
            m2.line
          ] })
        ] }, i3)) }) })
      ] }),
      /* @__PURE__ */ u3("div", { class: "card", children: [
        /* @__PURE__ */ u3("h3", { children: [
          "Keys missing in some locales (",
          partial.length,
          ")"
        ] }),
        /* @__PURE__ */ u3("table", { children: /* @__PURE__ */ u3("tbody", { children: partial.slice(0, 300).map((e3) => /* @__PURE__ */ u3("tr", { class: "click", tabIndex: 0, onClick: () => onEdit(e3), children: [
          /* @__PURE__ */ u3("td", { class: "mono", children: e3.key }),
          /* @__PURE__ */ u3("td", { children: e3.namespace }),
          /* @__PURE__ */ u3("td", { children: e3.missing.map((l3) => /* @__PURE__ */ u3("span", { class: "badge warn", children: l3 }, l3)) })
        ] }, e3.workspaceId + e3.namespace + e3.key)) }) })
      ] })
    ] });
  }
  function Hardcoded({ connected, onPick }) {
    const [scan, setScan] = d2(null);
    const [busy, setBusy] = d2(false);
    const [err, setErr] = d2("");
    const load = () => {
      setBusy(true);
      return api("GET", "/scan", void 0, 6e4).then((d3) => {
        setScan(d3);
        setErr("");
      }).catch((e3) => setErr(errText(e3))).finally(() => setBusy(false));
    };
    A(() => {
      if (connected) void load();
    }, [connected]);
    if (!connected) return /* @__PURE__ */ u3(Empty, { children: "Connect to the agent first." });
    return /* @__PURE__ */ u3("div", { class: "stack", children: [
      /* @__PURE__ */ u3("div", { class: "row", children: [
        /* @__PURE__ */ u3("button", { onClick: load, disabled: busy, children: busy ? "Scanning\u2026" : "Rescan" }),
        /* @__PURE__ */ u3("span", { class: "muted", children: [
          scan?.hardcoded?.length ?? 0,
          " hardcoded strings",
          scan?.truncated ? " (truncated)" : ""
        ] }),
        scan?.parseErrors?.length ? /* @__PURE__ */ u3("span", { class: "badge warn", children: [
          scan.parseErrors.length,
          " files skipped (parse errors)"
        ] }) : null,
        err && /* @__PURE__ */ u3("span", { class: "badge err", children: err })
      ] }),
      /* @__PURE__ */ u3("table", { children: [
        /* @__PURE__ */ u3("thead", { children: /* @__PURE__ */ u3("tr", { children: [
          /* @__PURE__ */ u3("th", { children: "Text" }),
          /* @__PURE__ */ u3("th", { children: "Kind" }),
          /* @__PURE__ */ u3("th", { children: "Location" }),
          /* @__PURE__ */ u3("th", {})
        ] }) }),
        /* @__PURE__ */ u3("tbody", { children: (scan?.hardcoded ?? []).map((h3, i3) => /* @__PURE__ */ u3("tr", { class: "click", tabIndex: 0, onClick: () => h3.canExtract && onPick(h3), children: [
          /* @__PURE__ */ u3("td", { children: h3.text }),
          /* @__PURE__ */ u3("td", { children: /* @__PURE__ */ u3("span", { class: "badge", children: h3.attr ? `${h3.kind}:${h3.attr}` : h3.kind }) }),
          /* @__PURE__ */ u3("td", { class: "muted mono", children: [
            h3.file,
            ":",
            h3.line
          ] }),
          /* @__PURE__ */ u3("td", { children: h3.canExtract ? "" : /* @__PURE__ */ u3("span", { class: "badge warn", title: "Not auto-extractable", children: "manual" }) })
        ] }, i3)) })
      ] })
    ] });
  }
  function Changes({ preview, result, onUndo, connected }) {
    const [hist, setHist] = d2([]);
    const load = () => api("GET", "/changes/history").then((d3) => setHist(d3.transactions)).catch(() => {
    });
    A(() => {
      if (connected) void load();
    }, [connected, result]);
    return /* @__PURE__ */ u3("div", { class: "stack", children: [
      preview ? preview.changes.map((c3) => /* @__PURE__ */ u3("div", { class: "card", children: [
        /* @__PURE__ */ u3("div", { class: "filebar", children: [
          /* @__PURE__ */ u3("span", { class: "badge", children: c3.kind }),
          c3.file,
          c3.created && /* @__PURE__ */ u3("span", { class: "badge ok", children: "new" })
        ] }),
        /* @__PURE__ */ u3(Diff, { text: c3.diff })
      ] }, c3.file)) : /* @__PURE__ */ u3(Empty, { children: "No pending preview. Select text in the Inspector and choose \u201CPreview changes\u201D." }),
      /* @__PURE__ */ u3("div", { class: "card", children: [
        /* @__PURE__ */ u3("h3", { children: "Recent transactions" }),
        /* @__PURE__ */ u3("div", { class: "body", children: [
          !hist.length && /* @__PURE__ */ u3("span", { class: "muted", children: "None yet." }),
          hist.map((h3) => /* @__PURE__ */ u3("div", { class: "row", children: [
            /* @__PURE__ */ u3("span", { class: "mono", children: h3.id }),
            /* @__PURE__ */ u3("span", { class: "badge " + (h3.state === "committed" ? "ok" : h3.state === "undone" ? "" : "warn"), children: h3.state }),
            /* @__PURE__ */ u3("span", { class: "muted grow", children: h3.files.join(", ") }),
            h3.state === "committed" && /* @__PURE__ */ u3("button", { onClick: () => onUndo(h3.id), children: "Undo" })
          ] }, h3.id))
        ] })
      ] })
    ] });
  }
  function Diagnostics({ conn, pageInfo, selection, resolveState, lastWrite, onReconnect }) {
    const [logs, setLogs] = d2({ bg: [], agent: [], agentExt: [], counters: null });
    const [steps, setSteps] = d2([]);
    const [busy, setBusy] = d2(false);
    const refresh = async () => {
      const [bg, ag] = await Promise.allSettled([rpc("bg.logs"), api("GET", "/diagnostics")]);
      setLogs({
        bg: bg.status === "fulfilled" ? bg.value.logs : [{ ts: (/* @__PURE__ */ new Date()).toISOString(), level: "ERROR", component: "panel", event: "bg.logs.failed", data: { message: String(bg.reason?.message) } }],
        agent: ag.status === "fulfilled" ? ag.value.logs : [],
        agentExt: ag.status === "fulfilled" ? ag.value.extensionLogs : [],
        counters: ag.status === "fulfilled" ? ag.value.counters : null,
        agentErr: ag.status === "rejected" ? errText(ag.reason) : ""
      });
    };
    A(() => {
      void refresh();
      const t3 = setInterval(refresh, 4e3);
      return () => clearInterval(t3);
    }, []);
    const selfCheck = async () => {
      setBusy(true);
      const out = [];
      const push = (s3) => {
        out.push(s3);
        setSteps([...out]);
      };
      const run = async (id, label, fn, skipIf = false) => {
        if (skipIf) {
          push({ id, label, state: "skip", detail: "skipped (previous step failed)" });
          return false;
        }
        try {
          push({ id, label, state: "ok", detail: await fn() });
          return true;
        } catch (e3) {
          push({ id, label, state: "fail", detail: errText(e3) });
          return false;
        }
      };
      plog("INFO", "selfcheck.started");
      let ok = await run("bg", "Extension background", async () => `worker v${(await rpc("bg.ping")).version}`);
      ok = await run("health", "Agent reachable", async () => {
        const s3 = await rpc("bg.agent.status");
        if (!s3.agentUrl) throw new Error("Agent URL not configured");
        if (!s3.connected && !s3.authFailed) throw new Error(s3.reason);
        return s3.agentUrl;
      }, !ok) && ok;
      ok = await run("auth", "Authenticated", async () => {
        const s3 = await rpc("bg.agent.status");
        if (!s3.connected) throw new Error(s3.reason ?? "Not connected");
        return `project \u201C${s3.project}\u201D \xB7 ${s3.framework}/${s3.provider}`;
      }, !ok) && ok;
      const ws = { n: 0 };
      ok = await run("ws", "Translation workspaces", async () => {
        const w2 = await api("GET", "/workspaces");
        const files = w2.workspaces.reduce((a3, x2) => a3 + x2.files.length, 0);
        ws.n = files;
        if (!files) throw new Error("No locale files found. Check workspaces in localelens.config.json");
        return `${w2.workspaces.length} workspace(s), ${files} locale file(s)`;
      }, !ok) && ok;
      const okAgent = ok;
      const cs = await run("cs", "Content script", async () => {
        const p3 = await page("content.ping");
        return `${p3.url}`;
      });
      let sample = null;
      const inst = await run("inst", "Runtime instrumentation", async () => {
        const p3 = await page("content.ping");
        if (!p3.instrumented) throw new Error("0 instrumented text nodes. Is the Vite/Next plugin enabled (dev mode only) and the page reloaded after `localelens dev`?");
        sample = await page("content.sample");
        return `${p3.instrumented} instrumented element(s)`;
      }, !cs);
      await run("resolve", "Source resolution (round trip)", async () => {
        const m2 = /^([a-f0-9]{8}):(\d+):([a-f0-9]{8})$/.exec(sample?.ref ?? "");
        if (!m2) throw new Error("No sample element");
        const r3 = await api("POST", "/source/resolve", { ref: { fileId: m2[1], n: +m2[2], fp: m2[3] }, text: sample.text });
        return `${r3.file}:${r3.candidates[0]?.line ?? "?"} \xB7 ${r3.candidates.length} candidate(s)`;
      }, !(inst && okAgent));
      plog("INFO", "selfcheck.completed", { data: { failed: out.filter((s3) => s3.state === "fail").length } });
      setBusy(false);
      void refresh();
    };
    const all = [...logs.bg, ...logs.agent, ...logs.agentExt].sort((a3, b3) => a3.ts.localeCompare(b3.ts)).slice(-300);
    const dot = (ok) => /* @__PURE__ */ u3("span", { class: "dot " + (ok === null ? "" : ok ? "ok" : "err") });
    const rows = [
      ["Agent connectivity", conn?.connected ?? false, conn?.connected ? conn.agentUrl : conn?.reason ?? "\u2014"],
      ["Authentication", conn?.connected ? true : conn?.authFailed ? false : null, conn?.connected ? "token accepted" : conn?.authFailed ? "token rejected" : "\u2014"],
      ["Active tab", tabId >= 0, tabId >= 0 ? `#${tabId}` : "not set"],
      ["Content script", pageInfo?.ok ?? null, pageInfo?.ok ? `v${pageInfo.version}` : pageInfo?.error ?? "\u2014"],
      ["Instrumented text nodes", pageInfo?.ok ? pageInfo.instrumented > 0 : null, pageInfo?.ok ? String(pageInfo.instrumented) : "\u2014"],
      ["Inspect mode", null, pageInfo?.inspecting ? "on" : "off"],
      ["Last selected node", selection ? !!selection.ref : null, selection ? `${selection.tag} \u201C${selection.text.slice(0, 30)}\u201D ${selection.ref ? "(mapped)" : "(no source mapping)"}` : "\u2014"],
      ["Source resolution", resolveState === "ok" ? true : resolveState === "fail" ? false : null, resolveState ?? "\u2014"],
      ["Last file write", lastWrite ? lastWrite.ok : null, lastWrite ? `${lastWrite.at}${lastWrite.error ? " \xB7 " + lastWrite.error : ""}` : "\u2014"]
    ];
    const bundle = () => ({
      generatedAt: (/* @__PURE__ */ new Date()).toISOString(),
      extension: chrome.runtime.getManifest().version,
      userAgent: navigator.userAgent,
      connection: { connected: conn?.connected, agentUrl: conn?.agentUrl, project: conn?.project, framework: conn?.framework, reason: conn?.reason },
      page: pageInfo,
      selfCheck: steps,
      counters: logs.counters,
      logs: all
    });
    const text = () => sanitizeText(JSON.stringify(bundle(), null, 2));
    return /* @__PURE__ */ u3("div", { class: "stack", children: [
      /* @__PURE__ */ u3("div", { class: "row", children: [
        /* @__PURE__ */ u3("button", { class: "primary", onClick: selfCheck, disabled: busy, children: busy ? "Running\u2026" : "Run self-check" }),
        /* @__PURE__ */ u3("button", { onClick: refresh, children: "Refresh diagnostics" }),
        /* @__PURE__ */ u3("button", { onClick: onReconnect, children: "Reconnect" }),
        /* @__PURE__ */ u3("button", { onClick: () => navigator.clipboard.writeText(sanitizeText(all.map((l3) => `${l3.ts} ${l3.level} ${l3.component} ${l3.event} ${l3.errorCode ?? ""} ${l3.data ? JSON.stringify(l3.data) : ""}`).join("\n"))), children: "Copy sanitized logs" }),
        /* @__PURE__ */ u3("button", { onClick: () => download(`localelens-diagnostics-${Date.now()}.json`, text()), children: "Export bundle" }),
        /* @__PURE__ */ u3("button", { onClick: async () => {
          await rpc("bg.logs.clear");
          await api("POST", "/diagnostics/clear", {}).catch(() => {
          });
          void refresh();
        }, children: "Clear logs" })
      ] }),
      /* @__PURE__ */ u3("div", { class: "cols two", children: [
        /* @__PURE__ */ u3("div", { class: "card", children: [
          /* @__PURE__ */ u3("h3", { children: "Status" }),
          /* @__PURE__ */ u3("table", { children: /* @__PURE__ */ u3("tbody", { children: rows.map(([k2, ok, d3]) => /* @__PURE__ */ u3("tr", { children: [
            /* @__PURE__ */ u3("td", { children: [
              dot(ok),
              " ",
              k2
            ] }),
            /* @__PURE__ */ u3("td", { class: "muted", children: d3 })
          ] }, k2)) }) })
        ] }),
        /* @__PURE__ */ u3("div", { class: "card", children: [
          /* @__PURE__ */ u3("h3", { children: [
            "Self-check ",
            steps.length ? "" : "(not run)"
          ] }),
          /* @__PURE__ */ u3("div", { class: "body", children: [
            /* @__PURE__ */ u3("ol", { class: "steps", children: steps.map((s3) => /* @__PURE__ */ u3("li", { children: [
              /* @__PURE__ */ u3("span", { class: "dot " + (s3.state === "ok" ? "ok" : s3.state === "fail" ? "err" : "") }),
              /* @__PURE__ */ u3("b", { children: s3.label }),
              /* @__PURE__ */ u3("span", { class: s3.state === "fail" ? "badge err" : "muted", children: s3.detail })
            ] }, s3.id)) }),
            steps.some((s3) => s3.state === "fail") && /* @__PURE__ */ u3("div", { class: "alert info", children: "First failing step is the component to fix. Troubleshooting: docs/TROUBLESHOOTING.md" }),
            !steps.length && /* @__PURE__ */ u3("span", { class: "muted", children: "Proves each hop: worker \u2192 agent \u2192 auth \u2192 content script \u2192 compiler instrumentation \u2192 source resolution. \u201CConnected\u201D alone proves only the token." })
          ] })
        ] })
      ] }),
      /* @__PURE__ */ u3("div", { class: "card", children: [
        /* @__PURE__ */ u3("h3", { children: [
          "Recent events ",
          logs.agentErr && /* @__PURE__ */ u3("span", { class: "badge err", children: [
            "agent logs unavailable: ",
            logs.agentErr
          ] })
        ] }),
        /* @__PURE__ */ u3("div", { class: "body log", style: "max-height:300px;overflow:auto", children: all.slice().reverse().map((l3, i3) => /* @__PURE__ */ u3("div", { class: l3.level[0], children: [
          l3.ts.slice(11, 23),
          " ",
          l3.level.padEnd(5),
          " [",
          l3.component,
          "] ",
          l3.event,
          l3.errorCode ? ` ${l3.errorCode}` : "",
          l3.durationMs ? ` ${l3.durationMs}ms` : "",
          l3.data ? " " + sanitizeText(JSON.stringify(l3.data)).slice(0, 160) : ""
        ] }, i3)) })
      ] })
    ] });
  }
  function Settings({ theme, setTheme, conn }) {
    return /* @__PURE__ */ u3("div", { class: "stack", style: "max-width:420px", children: [
      /* @__PURE__ */ u3("label", { children: [
        "Theme",
        /* @__PURE__ */ u3("select", { value: theme, onChange: (e3) => setTheme(e3.target.value), children: [
          /* @__PURE__ */ u3("option", { value: "auto", children: "Match DevTools / system" }),
          /* @__PURE__ */ u3("option", { value: "light", children: "Light" }),
          /* @__PURE__ */ u3("option", { value: "dark", children: "Dark" })
        ] })
      ] }),
      /* @__PURE__ */ u3("div", { class: "kv", children: [
        /* @__PURE__ */ u3("div", { children: [
          /* @__PURE__ */ u3("span", { class: "muted", children: "Agent" }),
          /* @__PURE__ */ u3("span", { class: "mono", children: conn?.agentUrl ?? "\u2014" })
        ] }),
        /* @__PURE__ */ u3("div", { children: [
          /* @__PURE__ */ u3("span", { class: "muted", children: "Source locale" }),
          /* @__PURE__ */ u3("span", { children: conn?.sourceLocale ?? "\u2014" })
        ] }),
        /* @__PURE__ */ u3("div", { children: [
          /* @__PURE__ */ u3("span", { class: "muted", children: "Writable roots" }),
          /* @__PURE__ */ u3("span", { children: (conn?.workspaces ?? []).map((w2) => w2.id + (w2.writable ? "" : " (read-only)")).join(", ") || "\u2014" })
        ] })
      ] }),
      /* @__PURE__ */ u3("div", { class: "alert info", children: "Session token lives in extension session storage only: cleared when the browser closes. Never logged or exported." })
    ] });
  }

  // src/panel/main.tsx
  var TABS = [
    ["overview", "Overview"],
    ["inspector", "Inspector"],
    ["translations", "Translations"],
    ["hardcoded", "Hardcoded"],
    ["missing", "Missing Keys"],
    ["changes", "Changes / Diff"],
    ["diagnostics", "Diagnostics"],
    ["settings", "Settings"]
  ];
  var errText2 = (e3) => `${e3?.message ?? e3}${e3?.code ? ` (${e3.code})` : ""}`;
  var lsGet = (k2, d3) => {
    try {
      return localStorage.getItem(k2) ?? d3;
    } catch {
      return d3;
    }
  };
  var lsSet = (k2, v3) => {
    try {
      localStorage.setItem(k2, v3);
    } catch {
    }
  };
  function App() {
    const [tab, setTab] = d2(initialTab);
    const [theme, setThemeState] = d2(lsGet("ll.theme", "auto"));
    const [conn, setConn] = d2(null);
    const [pageInfo, setPageInfo] = d2(null);
    const [workspaces, setWorkspaces] = d2([]);
    const [sel, setSel] = d2(null);
    const [res, setRes] = d2(null);
    const [resState, setResState] = d2();
    const [resErr, setResErr] = d2("");
    const [candId, setCandId] = d2("");
    const [form, setForm] = d2(null);
    const [preview, setPreview] = d2(null);
    const [result, setResult] = d2(null);
    const [busy, setBusy] = d2("");
    const [err, setErr] = d2("");
    const [lastWrite, setLastWrite] = d2(null);
    const [scanCount, setScanCount] = d2(null);
    const setTheme = (t3) => {
      setThemeState(t3);
      lsSet("ll.theme", t3);
    };
    A(() => {
      const dt = typeof chrome !== "undefined" && chrome.devtools?.panels?.themeName;
      document.documentElement.dataset.theme = theme === "auto" ? dt === "dark" ? "dark" : dt ? "light" : "" : theme;
      if (theme === "auto" && !dt) delete document.documentElement.dataset.theme;
    }, [theme]);
    const refresh = j2(async () => {
      try {
        setConn(await rpc("bg.agent.status", void 0, { timeoutMs: 6e3 }));
      } catch (e3) {
        setConn({ connected: false, reason: errText2(e3), code: e3.code });
      }
      try {
        setPageInfo({ ok: true, ...await page("content.ping") });
      } catch (e3) {
        setPageInfo({ ok: false, error: errText2(e3) });
      }
    }, []);
    A(() => {
      void refresh();
      const t3 = setInterval(refresh, 5e3);
      return () => clearInterval(t3);
    }, [refresh]);
    A(() => {
      if (!conn?.connected) return;
      api("GET", "/workspaces").then((d3) => setWorkspaces(d3.workspaces)).catch(() => {
      });
    }, [conn?.connected, conn?.project]);
    const resolve = j2(async (refStr, text, attr, preferCand, forced) => {
      setErr("");
      setResErr("");
      setRes(null);
      setForm(null);
      setPreview(null);
      setResult(null);
      setCandId("");
      const ref = parseRef(refStr);
      if (!ref) {
        setResState("fail");
        setResErr("This text has no source mapping (not compiled by the LocaleLens plugin: production build, third-party component, or the page needs a reload after starting `localelens dev`).");
        return;
      }
      setResState("resolving");
      plog("INFO", "source.resolve.started", { data: { n: ref.n } });
      try {
        const r3 = await api("POST", "/source/resolve", { ref, text, attr });
        setRes(r3);
        setResState("ok");
        plog("INFO", "source.resolve.completed", { data: { candidates: r3.candidates.length, ambiguous: r3.ambiguous } });
        const pick = r3.candidates.find((c3) => c3.id === preferCand) ?? r3.candidates.find((c3) => c3.confidence !== "low") ?? null;
        if (pick) await choose(r3, pick, ref, text, attr, forced);
      } catch (e3) {
        setResState("fail");
        setResErr(errText2(e3));
        plog("ERROR", "source.resolve.failed", { errorCode: e3.code });
      }
    }, [conn?.sourceLocale, workspaces]);
    const choose = async (r3, c3, ref, text, attr, forced) => {
      setCandId(c3.id);
      setPreview(null);
      setResult(null);
      setErr("");
      const sourceLocale = conn?.sourceLocale ?? "en";
      if (c3.kind === "i18n-call" && c3.key) {
        let wsId = r3.suggestedWorkspaceId ?? workspaces[0]?.id ?? "";
        let values = c3.values ?? {};
        try {
          const lk = await api("POST", "/translations/lookup", { namespace: c3.namespace, key: c3.key });
          if (lk.hits[0]) {
            wsId = lk.hits[0].workspaceId;
            values = lk.hits[0].values;
          }
        } catch {
        }
        plog("INFO", "translation.loaded", { data: { key: c3.key } });
        setForm({ mode: "edit", workspaceId: wsId, namespace: c3.namespace, key: c3.key, values, existing: Object.keys(values).length > 0 });
      } else if (c3.canExtract) {
        setForm({
          mode: "extract",
          workspaceId: r3.suggestedWorkspaceId ?? workspaces[0]?.id ?? "",
          namespace: r3.suggestedNamespace ?? "common",
          key: r3.suggestedKey ?? "",
          values: { [sourceLocale]: c3.template ?? c3.text },
          existing: false,
          source: { ref, candidateId: c3.id, text, attr }
        });
      } else setForm(null);
      void forced;
    };
    const onSelected = j2((p3) => {
      plog("INFO", "panel.selection_received", { data: { mapped: !!p3.ref } });
      setSel(p3);
      setTab("inspector");
      setInspecting(false);
      void resolve(p3.ref, p3.text, p3.attr);
    }, [resolve]);
    const [inspecting, setInspecting] = d2(false);
    const selRef = T2(onSelected);
    selRef.current = onSelected;
    A(() => {
      const h3 = (msg, sender) => {
        if (msg?.v !== 1 || msg.kind !== "evt" || sender.tab?.id !== tabId) return;
        if (msg.type === "element.selected") selRef.current(msg.payload);
        if (msg.type === "inspect.changed") setInspecting(!!msg.payload?.inspecting);
      };
      chrome.runtime.onMessage.addListener(h3);
      rpc("bg.lastSelection", { tabId }).then((s3) => {
        if (s3 && Date.now() - s3.at < 5 * 6e4) {
          setSel(s3);
          void resolve(s3.ref, s3.text, s3.attr);
        }
      }).catch(() => {
      });
      return () => chrome.runtime.onMessage.removeListener(h3);
    }, []);
    const toggleInspect = async () => {
      setErr("");
      try {
        plog("INFO", "inspect.started");
        const r3 = await page("content.inspect", { on: !inspecting });
        setInspecting(r3.inspecting);
        if (r3.inspecting && !pageInfo?.instrumented) setErr("Inspecting, but this page has 0 instrumented elements; clicks will show \u201Cno source mapping\u201D. Run Diagnostics \u2192 self-check.");
      } catch (e3) {
        setErr(errText2(e3));
        plog("ERROR", "inspect.failed", { errorCode: e3.code });
      }
    };
    const doPreview = async () => {
      if (!form) return;
      setBusy("preview");
      setErr("");
      setResult(null);
      plog("INFO", "changes.preview.started");
      try {
        const values = Object.fromEntries(Object.entries(form.values).filter(([, v3]) => v3.trim() !== ""));
        const p3 = await api("POST", "/changes/preview", { mode: form.mode, workspaceId: form.workspaceId, namespace: form.namespace, key: form.key, values, source: form.source });
        setPreview(p3);
        plog("INFO", "changes.preview.completed", { data: { files: p3.changes.length } });
      } catch (e3) {
        setErr(errText2(e3));
        setPreview(null);
        plog("WARN", "changes.preview.failed", { errorCode: e3.code });
      } finally {
        setBusy("");
      }
    };
    const doCommit = async () => {
      if (!preview) return;
      setBusy("commit");
      setErr("");
      plog("INFO", "changes.commit.started");
      try {
        const watch = page("content.watchDom", { timeoutMs: 8e3 }, 9e3).catch(() => null);
        const r3 = await api("POST", "/changes/commit", { operationId: preview.operationId });
        plog("INFO", "changes.commit.completed", { data: { transactionId: r3.transactionId } });
        setLastWrite({ at: (/* @__PURE__ */ new Date()).toLocaleTimeString(), ok: r3.verified, transactionId: r3.transactionId });
        setResult({ ...r3, hmr: "waiting" });
        setPreview(null);
        const w2 = await watch;
        setResult((x2) => ({ ...x2, hmr: w2?.detected ? `Page updated (DOM change observed after ${w2.ms} ms)` : "Files written, but no DOM change was observed within 8 s. Your dev server may need a manual reload." }));
      } catch (e3) {
        setErr(errText2(e3));
        setLastWrite({ at: (/* @__PURE__ */ new Date()).toLocaleTimeString(), ok: false, error: errText2(e3) });
        plog("ERROR", "changes.commit.failed", { errorCode: e3.code });
      } finally {
        setBusy("");
      }
    };
    const doUndo = async (id) => {
      setBusy("undo");
      setErr("");
      try {
        await api("POST", "/changes/undo", { transactionId: id });
        setResult({ undone: id });
      } catch (e3) {
        setErr(errText2(e3));
      } finally {
        setBusy("");
      }
    };
    const openEditor = async () => {
      if (!res || !sel) return;
      const ref = parseRef(sel.ref);
      const c3 = res.candidates.find((x2) => x2.id === candId);
      if (!ref) return;
      try {
        const u4 = await api("POST", "/source/editor-url", { fileId: ref.fileId, line: c3?.line ?? 1 });
        window.open(u4.url);
      } catch (e3) {
        setErr(errText2(e3));
      }
    };
    const loadFromTranslation = (e3) => {
      setSel(null);
      setRes(null);
      setPreview(null);
      setResult(null);
      setErr("");
      const ws = workspaces.find((w2) => w2.id === e3.workspaceId)?.id ?? workspaces[0]?.id ?? "";
      setForm({ mode: "edit", workspaceId: ws, namespace: e3.namespace, key: e3.key, values: e3.values, existing: Object.keys(e3.values).length > 0 });
      setTab("inspector");
    };
    const loadFromHardcoded = (h3) => {
      setSel({ ref: `${h3.ref.fileId}:${h3.ref.n}:${h3.ref.fp}`, text: h3.text, attr: h3.attr, tag: "source", rect: { x: 0, y: 0, w: 0, h: 0 } });
      setTab("inspector");
      void resolve(`${h3.ref.fileId}:${h3.ref.n}:${h3.ref.fp}`, h3.text, h3.attr, h3.candidateId);
    };
    const connected = !!conn?.connected;
    const cand = res?.candidates?.find((c3) => c3.id === candId);
    const locales = (() => {
      const ws = workspaces.find((w2) => w2.id === form?.workspaceId);
      const s3 = /* @__PURE__ */ new Set([conn?.sourceLocale ?? "en", ...ws?.locales ?? [], ...Object.keys(form?.values ?? {})]);
      return [...s3];
    })();
    const nsLocked = (() => {
      const w2 = workspaces.find((x2) => x2.id === form?.workspaceId);
      return w2 && w2.pattern && !w2.pattern.includes("{ns}") ? w2.namespaces?.[0] ?? null : null;
    })();
    const status = /* @__PURE__ */ u3("div", { class: "status-line", role: "status", children: [
      /* @__PURE__ */ u3("span", { children: [
        /* @__PURE__ */ u3("span", { class: "dot " + (connected ? "ok" : "err") }),
        " Agent ",
        connected ? `\xB7 ${conn.project}` : "disconnected"
      ] }),
      /* @__PURE__ */ u3("span", { children: [
        /* @__PURE__ */ u3("span", { class: "dot " + (pageInfo?.ok ? pageInfo.instrumented ? "ok" : "warn" : "err") }),
        " ",
        pageInfo?.ok ? `${pageInfo.instrumented} mapped text nodes` : "page not reachable"
      ] }),
      inspecting && /* @__PURE__ */ u3("span", { class: "badge warn", children: "inspecting\u2026" })
    ] });
    return /* @__PURE__ */ u3(M, { children: [
      /* @__PURE__ */ u3("div", { class: "tabs", role: "tablist", "aria-label": "LocaleLens", children: TABS.map(([id, label]) => /* @__PURE__ */ u3("button", { role: "tab", "aria-selected": tab === id, onClick: () => setTab(id), children: label }, id)) }),
      status,
      /* @__PURE__ */ u3("main", { children: [
        tab === "overview" && /* @__PURE__ */ u3(Overview, { conn, pageInfo, go: setTab, scan: scanCount, setScan: setScanCount }),
        tab === "inspector" && /* @__PURE__ */ u3("div", { class: "cols two", children: [
          /* @__PURE__ */ u3("div", { class: "stack", style: "align-content:start", children: [
            /* @__PURE__ */ u3("div", { class: "row", children: [
              /* @__PURE__ */ u3("button", { class: inspecting ? "" : "primary", onClick: toggleInspect, disabled: !connected && !pageInfo?.ok, children: inspecting ? "Stop inspecting (Esc)" : "Inspect Text" }),
              !connected && /* @__PURE__ */ u3("span", { class: "badge err", children: "Connect the agent in the popup" })
            ] }),
            err && /* @__PURE__ */ u3("div", { class: "alert err", role: "alert", children: err }),
            /* @__PURE__ */ u3("div", { class: "card", children: [
              /* @__PURE__ */ u3("h3", { children: "Selection" }),
              /* @__PURE__ */ u3("div", { class: "body", children: !sel ? /* @__PURE__ */ u3("span", { class: "muted", children: [
                "Click ",
                /* @__PURE__ */ u3("b", { children: "Inspect Text" }),
                ", hover the page, click a piece of text."
              ] }) : /* @__PURE__ */ u3(M, { children: [
                /* @__PURE__ */ u3("div", { class: "sel-text", children: sel.text || "(no text)" }),
                /* @__PURE__ */ u3("div", { class: "row muted", children: [
                  /* @__PURE__ */ u3("span", { class: "mono", children: [
                    "<",
                    sel.tag,
                    ">"
                  ] }),
                  sel.attr && /* @__PURE__ */ u3("span", { class: "badge", children: sel.attr }),
                  res && /* @__PURE__ */ u3("span", { class: "mono", children: [
                    res.file,
                    cand ? `:${cand.line}` : ""
                  ] }),
                  resState === "resolving" && /* @__PURE__ */ u3("span", { children: "resolving\u2026" })
                ] }),
                resErr && /* @__PURE__ */ u3("div", { class: "alert err", role: "alert", children: resErr }),
                res?.extractBlocked && /* @__PURE__ */ u3("div", { class: "alert warn", children: res.extractBlocked }),
                res?.ambiguous && /* @__PURE__ */ u3("div", { class: "alert warn", children: "Several occurrences in this element match. Pick the right one; LocaleLens will not guess." }),
                res && /* @__PURE__ */ u3("div", { class: "stack", role: "radiogroup", "aria-label": "Source occurrences", children: res.candidates.map((c3) => /* @__PURE__ */ u3(
                  "div",
                  {
                    class: "cand",
                    role: "radio",
                    tabIndex: 0,
                    "aria-checked": c3.id === candId,
                    onClick: () => choose(res, c3, parseRef(sel.ref), sel.text, sel.attr),
                    onKeyDown: (k2) => (k2.key === "Enter" || k2.key === " ") && choose(res, c3, parseRef(sel.ref), sel.text, sel.attr),
                    children: [
                      /* @__PURE__ */ u3("span", { class: "badge " + (c3.confidence === "exact" ? "ok" : c3.confidence === "pattern" ? "" : "warn"), children: c3.confidence }),
                      /* @__PURE__ */ u3("div", { children: [
                        /* @__PURE__ */ u3("div", { children: c3.kind === "i18n-call" ? /* @__PURE__ */ u3(M, { children: [
                          /* @__PURE__ */ u3("span", { class: "mono", children: [
                            c3.namespace,
                            ":",
                            c3.key
                          ] }),
                          " ",
                          /* @__PURE__ */ u3("span", { class: "muted", children: [
                            "\u2192 ",
                            c3.text || "(no value)"
                          ] })
                        ] }) : c3.template ?? c3.text }),
                        /* @__PURE__ */ u3("div", { class: "why", children: [
                          c3.kind,
                          c3.attr ? ` \xB7 ${c3.attr}` : "",
                          " \xB7 line ",
                          c3.line,
                          c3.kind === "i18n-call" ? " \xB7 already translated" : c3.canExtract ? " \xB7 extractable" : "",
                          c3.reason ? ` \xB7 ${c3.reason}` : ""
                        ] })
                      ] })
                    ]
                  },
                  c3.id
                )) }),
                /* @__PURE__ */ u3("div", { class: "row", children: /* @__PURE__ */ u3("button", { onClick: openEditor, disabled: !res, children: "Open source in editor" }) })
              ] }) })
            ] })
          ] }),
          /* @__PURE__ */ u3("div", { class: "stack", style: "align-content:start", children: [
            form ? /* @__PURE__ */ u3(
              FormCard,
              {
                form,
                setForm: (f3) => {
                  setForm(f3);
                  setPreview(null);
                },
                workspaces,
                locales,
                nsLocked,
                busy,
                onPreview: doPreview,
                onSuggest: async () => {
                  const t3 = form.values[conn?.sourceLocale ?? "en"] ?? "";
                  try {
                    const s3 = await api("POST", "/keys/suggest", { text: t3, namespace: form.namespace });
                    setForm({ ...form, key: s3.key });
                  } catch (e3) {
                    setErr(errText2(e3));
                  }
                }
              }
            ) : /* @__PURE__ */ u3(Empty, { children: sel && !resErr && resState !== "resolving" ? "This occurrence cannot be edited automatically. See the reason on the left; edit the source manually." : "Select text to edit its translation." }),
            preview && /* @__PURE__ */ u3(PreviewCard, { preview, busy, onCommit: doCommit, onCancel: () => setPreview(null) }),
            result && !result.undone && /* @__PURE__ */ u3("div", { class: "alert " + (result.verified ? "ok" : "err"), role: "status", children: [
              /* @__PURE__ */ u3("b", { children: result.verified ? "Written and verified on disk." : "Written, but verification failed." }),
              " ",
              result.files.length,
              " file(s) \xB7 transaction ",
              /* @__PURE__ */ u3("span", { class: "mono", children: result.transactionId }),
              /* @__PURE__ */ u3("div", { children: result.hmr === "waiting" ? "Waiting for the app to hot-reload\u2026" : result.hmr }),
              /* @__PURE__ */ u3("button", { onClick: () => doUndo(result.transactionId), disabled: busy === "undo", children: "Undo" })
            ] }),
            result?.undone && /* @__PURE__ */ u3("div", { class: "alert ok", role: "status", children: [
              "Transaction ",
              result.undone,
              " was undone."
            ] })
          ] })
        ] }),
        tab === "translations" && /* @__PURE__ */ u3(Translations, { connected, onEdit: loadFromTranslation }),
        tab === "hardcoded" && /* @__PURE__ */ u3(Hardcoded, { connected, onPick: loadFromHardcoded }),
        tab === "missing" && /* @__PURE__ */ u3(MissingKeys, { connected, onEdit: loadFromTranslation }),
        tab === "changes" && /* @__PURE__ */ u3(Changes, { preview, result, onUndo: doUndo, connected }),
        tab === "diagnostics" && /* @__PURE__ */ u3(Diagnostics, { conn, pageInfo, selection: sel, resolveState: resState, lastWrite, onReconnect: refresh }),
        tab === "settings" && /* @__PURE__ */ u3(Settings, { theme, setTheme, conn })
      ] })
    ] });
  }
  function Overview({ conn, pageInfo, go, scan, setScan }) {
    A(() => {
      if (!conn?.connected) return;
      api("GET", "/scan", void 0, 6e4).then((s3) => setScan({ h: s3.hardcoded.length, m: s3.missingKeys.length })).catch(() => {
      });
    }, [conn?.connected]);
    const item = (ok, title, detail) => /* @__PURE__ */ u3("li", { children: [
      /* @__PURE__ */ u3("span", { class: "dot " + (ok === null ? "" : ok ? "ok" : "err") }),
      /* @__PURE__ */ u3("b", { children: title }),
      /* @__PURE__ */ u3("span", { class: "muted", children: detail })
    ] });
    return /* @__PURE__ */ u3("div", { class: "cols two", children: [
      /* @__PURE__ */ u3("div", { class: "card", children: [
        /* @__PURE__ */ u3("h3", { children: "Pipeline" }),
        /* @__PURE__ */ u3("div", { class: "body", children: [
          /* @__PURE__ */ u3("ol", { class: "steps", children: [
            item(conn?.connected ?? false, "Local agent", conn?.connected ? `${conn.project} \xB7 ${conn.framework} \xB7 ${conn.provider}` : conn?.reason ?? "not connected"),
            item(pageInfo?.ok ?? false, "Content script", pageInfo?.ok ? pageInfo.url : pageInfo?.error ?? "\u2014"),
            item(pageInfo?.ok ? pageInfo.instrumented > 0 : null, "Instrumentation", pageInfo?.ok ? `${pageInfo.instrumented} mapped text nodes` : "\u2014"),
            item(conn?.connected ? conn.workspaces.length > 0 : null, "Workspaces", conn?.connected ? conn.workspaces.map((w2) => w2.id).join(", ") : "\u2014")
          ] }),
          /* @__PURE__ */ u3("span", { class: "muted", children: "A green \u201Cconnected\u201D dot only proves the token. Run the end-to-end self-check in Diagnostics." }),
          /* @__PURE__ */ u3("div", { class: "row", children: [
            /* @__PURE__ */ u3("button", { class: "primary", onClick: () => go("diagnostics"), children: "Open diagnostics" }),
            /* @__PURE__ */ u3("button", { onClick: () => go("inspector"), children: "Go to Inspector" })
          ] })
        ] })
      ] }),
      /* @__PURE__ */ u3("div", { class: "card", children: [
        /* @__PURE__ */ u3("h3", { children: "Project health" }),
        /* @__PURE__ */ u3("div", { class: "body", children: [
          /* @__PURE__ */ u3("div", { class: "row", children: [
            /* @__PURE__ */ u3("b", { children: scan?.h ?? "\u2014" }),
            " hardcoded strings ",
            /* @__PURE__ */ u3("button", { class: "link", onClick: () => go("hardcoded"), children: "review" })
          ] }),
          /* @__PURE__ */ u3("div", { class: "row", children: [
            /* @__PURE__ */ u3("b", { children: scan?.m ?? "\u2014" }),
            " keys used but undefined ",
            /* @__PURE__ */ u3("button", { class: "link", onClick: () => go("missing"), children: "review" })
          ] })
        ] })
      ] })
    ] });
  }
  function FormCard({ form, setForm, workspaces, locales, nsLocked, busy, onPreview, onSuggest }) {
    const set = (p3) => setForm({ ...form, ...p3 });
    const ws = workspaces.find((w2) => w2.id === form.workspaceId);
    const keyOk = /^[\w$-]+(\.[\w$-]+)*$/.test(form.key);
    return /* @__PURE__ */ u3("div", { class: "card", children: [
      /* @__PURE__ */ u3("h3", { children: form.mode === "edit" ? "Edit translation" : "Extract hardcoded text" }),
      /* @__PURE__ */ u3("div", { class: "body", children: [
        /* @__PURE__ */ u3("div", { class: "row", children: [
          /* @__PURE__ */ u3("label", { class: "grow", children: [
            "Workspace",
            /* @__PURE__ */ u3("select", { value: form.workspaceId, onChange: (e3) => set({ workspaceId: e3.target.value }), children: workspaces.map((w2) => /* @__PURE__ */ u3("option", { value: w2.id, disabled: !w2.writable, children: [
              w2.id,
              " \u2014 ",
              w2.root,
              w2.writable ? "" : " (read-only)"
            ] }, w2.id)) })
          ] }),
          /* @__PURE__ */ u3("label", { style: "width:130px", children: [
            "Namespace",
            /* @__PURE__ */ u3("input", { class: "mono", value: nsLocked ?? form.namespace, disabled: !!nsLocked, onInput: (e3) => set({ namespace: e3.target.value }) })
          ] })
        ] }),
        /* @__PURE__ */ u3("label", { children: [
          "Key",
          /* @__PURE__ */ u3("div", { class: "row", children: [
            /* @__PURE__ */ u3("input", { class: "mono grow", value: form.key, "aria-invalid": !keyOk, onInput: (e3) => set({ key: e3.target.value }), readOnly: form.mode === "edit" && form.existing }),
            form.mode === "extract" && /* @__PURE__ */ u3("button", { type: "button", onClick: onSuggest, children: "Suggest" })
          ] })
        ] }),
        ws && /* @__PURE__ */ u3("div", { class: "muted", children: [
          "Files: ",
          /* @__PURE__ */ u3("span", { class: "mono", children: [
            ws.root,
            "/",
            ws.pattern
          ] })
        ] }),
        locales.map((l3) => /* @__PURE__ */ u3("label", { children: [
          l3,
          form.values[l3] === void 0 && form.mode === "edit" ? /* @__PURE__ */ u3("span", { class: "badge warn", style: "margin-left:6px", children: "missing" }) : null,
          /* @__PURE__ */ u3("textarea", { rows: 2, value: form.values[l3] ?? "", onInput: (e3) => set({ values: { ...form.values, [l3]: e3.target.value } }) })
        ] }, l3)),
        /* @__PURE__ */ u3("div", { class: "row", children: [
          /* @__PURE__ */ u3("button", { class: "primary", onClick: onPreview, disabled: !keyOk || !form.workspaceId || busy === "preview", children: busy === "preview" ? "Previewing\u2026" : "Preview changes" }),
          /* @__PURE__ */ u3("span", { class: "muted", children: "Nothing is written until you apply." })
        ] })
      ] })
    ] });
  }
  function PreviewCard({ preview, busy, onCommit, onCancel }) {
    return /* @__PURE__ */ u3("div", { class: "card", children: [
      /* @__PURE__ */ u3("h3", { children: [
        "Preview \xB7 ",
        preview.changes.length,
        " file(s)"
      ] }),
      /* @__PURE__ */ u3("div", { class: "body", children: [
        preview.diagnostics.map((d3, i3) => /* @__PURE__ */ u3("div", { class: "alert " + (d3.level === "warn" ? "warn" : "info"), children: d3.message }, i3)),
        preview.changes.map((c3) => /* @__PURE__ */ u3("div", { children: [
          /* @__PURE__ */ u3("div", { class: "filebar", children: [
            /* @__PURE__ */ u3("span", { class: "badge", children: c3.kind }),
            c3.file,
            c3.created && /* @__PURE__ */ u3("span", { class: "badge ok", children: "new file" })
          ] }),
          /* @__PURE__ */ u3(Diff, { text: c3.diff })
        ] }, c3.file)),
        /* @__PURE__ */ u3("div", { class: "row", children: [
          /* @__PURE__ */ u3("button", { class: "primary", onClick: onCommit, disabled: busy === "commit", children: busy === "commit" ? "Applying\u2026" : "Apply changes" }),
          /* @__PURE__ */ u3("button", { onClick: onCancel, children: "Cancel" })
        ] })
      ] })
    ] });
  }
  G(/* @__PURE__ */ u3(App, {}), document.getElementById("app"));
})();
