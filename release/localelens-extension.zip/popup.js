"use strict";
(() => {
  // src/common.ts
  var RpcError = class extends Error {
    constructor(code, message, component = "unknown") {
      super(message);
      this.code = code;
      this.component = component;
    }
    code;
    component;
  };
  var uid = () => crypto.randomUUID().slice(0, 12);
  async function rpc(type, payload, opts = {}) {
    const req = { v: 1, kind: "req", id: uid(), type, tabId: opts.tabId, payload };
    const timeoutMs = opts.timeoutMs ?? 1e4;
    let timer;
    const timeout = new Promise((_, rej) => {
      timer = setTimeout(() => rej(new RpcError("TIMEOUT", `No response to ${type} within ${timeoutMs}ms`, "messaging")), timeoutMs);
    });
    try {
      const res = await Promise.race([chrome.runtime.sendMessage(req), timeout]);
      if (!res) throw new RpcError("NO_RECEIVER", `Nobody answered ${type} (background worker not reachable)`, "messaging");
      if (!res.ok) throw new RpcError(res.error?.code ?? "ERROR", res.error?.message ?? "Request failed", res.error?.component ?? "unknown");
      return res.payload;
    } catch (e) {
      if (e instanceof RpcError) throw e;
      throw new RpcError("NO_RECEIVER", e.message || "Messaging failed", "messaging");
    } finally {
      clearTimeout(timer);
    }
  }

  // src/popup.ts
  var $ = (id) => document.getElementById(id);
  var esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
  var activeTab;
  function showError(msg) {
    const el = $("error");
    el.hidden = !msg;
    el.textContent = msg ?? "";
  }
  async function refresh() {
    [activeTab] = await chrome.tabs.query({ active: true, currentWindow: true });
    let st;
    try {
      st = await rpc("bg.agent.status", void 0, { timeoutMs: 6e3 });
    } catch (e) {
      st = { connected: false, reason: e.message };
    }
    const pill = $("state");
    pill.textContent = st.connected ? "Connected" : "Disconnected";
    pill.className = "pill " + (st.connected ? "ok" : "err");
    if (st.agentUrl) $("url").value = st.agentUrl;
    $("tokenRow").hidden = !!st.connected;
    $("connectBtn").hidden = !!st.connected;
    $("disconnectBtn").hidden = !st.connected;
    $("reconnectBtn").hidden = !st.agentUrl;
    const rows = [
      ["Project", st.connected ? st.project : "\u2014"],
      ["Framework", st.connected ? `${st.framework} \xB7 ${st.provider}` : "\u2014"],
      ["Agent", st.connected ? `v${st.version} \xB7 up ${st.uptimeSec}s \xB7 ${st.indexedFiles} source files` : st.reason ?? "\u2014"],
      ["Active tab", activeTab?.url ? new URL(activeTab.url).host || activeTab.url : "\u2014"]
    ];
    $("info").innerHTML = rows.map(([k, v]) => `<div><span class="muted">${esc(k)}</span><span>${esc(v)}</span></div>`).join("");
    if (!st.connected && st.reason && st.agentUrl) showError(st.reason);
    await checkSite();
  }
  async function checkSite() {
    const row = $("siteRow");
    row.hidden = true;
    if (!activeTab?.url || !activeTab.id) return;
    let u;
    try {
      u = new URL(activeTab.url);
    } catch {
      return;
    }
    if (!/^https?:$/.test(u.protocol)) {
      row.hidden = false;
      $("siteMsg").textContent = "LocaleLens cannot run on this kind of page.";
      $("siteBtn").hidden = true;
      return;
    }
    if (["localhost", "127.0.0.1", "[::1]"].includes(u.hostname) || u.hostname.endsWith(".localhost")) return;
    const { granted } = await rpc("bg.siteAccess", { origin: u.origin });
    if (!granted) {
      row.hidden = false;
      $("siteMsg").textContent = `${u.host} is not a localhost origin.`;
      $("siteBtn").hidden = false;
    }
  }
  async function connect() {
    showError(null);
    $("connectBtn").setAttribute("disabled", "");
    try {
      await rpc("bg.agent.connect", { url: $("url").value.trim(), token: $("token").value.trim() });
      $("token").value = "";
    } catch (e) {
      const err = e;
      showError(err.code === "UNAUTHORIZED" ? "Invalid session token. Copy the token printed by `localelens dev`." : `${err.message} (${err.code})`);
    } finally {
      $("connectBtn").removeAttribute("disabled");
      await refresh();
    }
  }
  $("connect").addEventListener("submit", (e) => {
    e.preventDefault();
    void connect();
  });
  $("disconnectBtn").addEventListener("click", async () => {
    await rpc("bg.agent.disconnect");
    showError(null);
    await refresh();
  });
  $("reconnectBtn").addEventListener("click", async () => {
    showError(null);
    await refresh();
  });
  $("siteBtn").addEventListener("click", async () => {
    if (!activeTab?.url || !activeTab.id) return;
    const origin = new URL(activeTab.url).origin;
    const granted = await chrome.permissions.request({ origins: [origin + "/*"] });
    if (granted) {
      try {
        await rpc("bg.injectTab", { tabId: activeTab.id });
      } catch (e) {
        showError(e.message);
      }
    }
    await refresh();
  });
  $("diagBtn").addEventListener("click", () => {
    const q = activeTab?.id ? `?inspectedTabId=${activeTab.id}&tab=diagnostics` : "?tab=diagnostics";
    void chrome.tabs.create({ url: chrome.runtime.getURL("panel.html") + q });
  });
  void refresh();
})();
