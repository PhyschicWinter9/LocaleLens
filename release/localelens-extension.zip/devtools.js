"use strict";
(() => {
  // src/devtools.ts
  chrome.devtools.panels.create("LocaleLens", "icons/16.png", "panel.html", () => {
  });
})();
